#include <stdio.h>
#include <signal.h>


static void proc_notify(int sig)
{
	printf("receive gpio notify. %d SIGRTMIN+10 :%d\n", sig, SIGRTMIN+10);
} 


static void signal_handle(void)
{
    signal(SIGUSR1,  &proc_notify);
	
    signal(SIGUSR2,  &proc_notify);//bus error/**/
    
    signal(42,  &proc_notify);//bus error/**/
}


int main(int argc, char **argv)
{
	signal_handle();

	while (1) {
		pause();
	}

	return 0;
}

