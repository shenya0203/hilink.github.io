/*
 * $Id: //WIFI_SOC/MP/SDK_4_3_0_0/RT288x_SDK/source/user/rt2880_app/gpio/gpio.c#4 $
 */

#include <stdio.h>             
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include "ralink_gpio.h"

#define GPIO_DEV "/dev/gpio"

#if 0
typedef struct {
        int gpio;                       //gpio number (0 ~ 23)
        unsigned int on;                //interval of led on
        unsigned int off;               //interval of led off
        unsigned int blinks;            //number of blinking cycles
        unsigned int rests;             //number of break cycles
        unsigned int times;             //blinking times
} ralink_gpio_led_info;
#endif

enum {
	gpio_in,	//输入
	gpio_out,	//输出
};
enum {
	gpio3100,
	gpio6332,
	gpio9564,
};

int gpio_get_dir(int r)
{
	int fd, req;
	int data;
	
	fd = open(GPIO_DEV, O_RDONLY);
	if (fd < 0) {
		perror(GPIO_DEV);
		return -1;
	}

	if (r == gpio9564) {
		req = RALINK_GPIO9564_GET_DIR;
	} else if (r == gpio6332) {
		req = RALINK_GPIO6332_GET_DIR;
	} else {
		req = RALINK_GPIO_GET_DIR;
	}

	if (ioctl(fd, req, (void *)&data) < 0) {
		
		perror("RALINK_GPIO_GET_DIR fail.\n");
		
		close(fd);
		return -1;
	}

	//printf("gpio get 3100 :%x\n", data);
	
	close(fd);

	return data;
}

int gpio_set_dir(int r, int dir)
{
	int fd, req;

	fd = open(GPIO_DEV, O_RDONLY);
	if (fd < 0) {
		perror(GPIO_DEV);
		return -1;
	}

	if (r == gpio9564) {
		req = RALINK_GPIO9564_SET_DIR;
	} else if (r == gpio6332) {
		req = RALINK_GPIO6332_SET_DIR;
	} else {
		req = RALINK_GPIO_SET_DIR;
	}
	
	if (ioctl(fd, req, dir) < 0) {
		perror("ioctl");
		close(fd);
		return -1;
	}
	
	close(fd);
	
	return 0;
}



int gpio_write(int r, int value)
{
	int fd, req;

	fd = open(GPIO_DEV, O_RDONLY);
	if (fd < 0) {
		perror(GPIO_DEV);
		return -1;
	}
	
	if (r == gpio9564)
		req = RALINK_GPIO9564_WRITE;
	else if (r == gpio6332)
		req = RALINK_GPIO6332_WRITE;
	else
		req = RALINK_GPIO_WRITE;
	
	if (ioctl(fd, req, value) < 0) {
		perror("RALINK_GPIO_WRITE fail.\n");
		close(fd);
		exit(1);
		return -1;
	}
	
	close(fd);
	
	return 0;
}

int gpio_read(int r)
{
	int fd, req;
	int data;

	fd = open(GPIO_DEV, O_RDONLY);
	if (fd < 0) {
		perror(GPIO_DEV);
		exit(1);	//over
	}

	if (r == gpio9564) {
		req = RALINK_GPIO9564_READ;
	} else if (r == gpio6332) {
		req = RALINK_GPIO6332_READ;
	} else {
		req = RALINK_GPIO_READ;
	}
	
	if (ioctl(fd, req, (void *)&data) < 0) {
		
		perror("RALINK_GPIO_READ fail.\n");
		close(fd);
		exit(1);	//over
	}

	printf("GPIO READ :%x\n", data);
	
	close(fd);
	
	return data;
}

int gpio_int_reg(int gpio, int pid) 
{
	int fd, req;
	ralink_gpio_reg_info data;

	fd = open(GPIO_DEV, O_RDONLY);
	if (fd < 0) {
		perror(GPIO_DEV);
		exit(1);	//over
	}

	data.irq = gpio;
	data.pid = pid;
	
	if (ioctl(fd, RALINK_GPIO_REG_IRQ, (void *)&data) < 0) {
		
		perror("RALINK_GPIO_REG_IRQ fail.\n");
		
		close(fd);
		exit(1);	//over
	}
	
	close(fd);

	return 0;
}

int gpio_get_agpiocfg(void)
{
	int fd, req;
	int data;

	fd = open(GPIO_DEV, O_RDONLY);
	if (fd < 0) {
		perror(GPIO_DEV);
		exit(1);	//over
	}
	
	if (ioctl(fd, RALINK_GET_AGPIO_CFG, (void *)&data) < 0) {
		
		perror("RALINK_GET_AGPIO_CFG fail.\n");
		
		close(fd);
		exit(1);	//over
	}

	printf("AGPIO_CFG :%x\n", data);
	
	close(fd);

	return 0;
}

int gpio_get_gpio1_mode ()
{
	int fd, req;
	int data;

	fd = open(GPIO_DEV, O_RDONLY);
	if (fd < 0) {
		perror(GPIO_DEV);
		exit(1);	//over
	}
	
	if (ioctl(fd, RALINK_GET_GPIO1_MODE, (void *)&data) < 0) {
		
		perror("RALINK_GET_GPIO1_MODE fail.\n");
		
		close(fd);
		exit(1);	//over
	}

	printf("GPIO1 MODE :%x\n", data);
	
	close(fd);

	return 0;
}


int gpio_int_unreg(int gpio)
{

	return 0;
}

int gpio_init_dev()
{
	FILE * fp = NULL;
	char devnum[32] = {0};
	char driver[32] = {0};
	char cmd[64] = {0};
	
	fp = popen("cat /proc/devices | grep gpio | sed  -r -n \"s/[0-9]+ //p\"", "r");
		
	fscanf(fp, "%s", driver);
	pclose(fp);

	fp = popen("cat /proc/devices | grep gpio | sed  -r -n \"s/ [a-z0-9]*//p\"", "r");
	fscanf(fp, "%s", devnum);
	pclose(fp);

	if (strlen(driver) && strlen(devnum)) {
		snprintf(cmd, sizeof(cmd), "[ -c /dev/gpio ] || mknod /dev/gpio c %d 0", atoi(devnum));
		system(cmd);
	} else {
		printf("gpio module not enabled!\n");
		exit(1);
	}

}

void usage()
{
	printf("GPIO usage:\n");
	printf("gpio getdir [gpio]\n");
	printf("gpio setdir [gpio] [dir]     dir----0:IN 1:OUT\n");
	printf("gpio read   [gpio]\n");
	printf("gpio write  [gpio] [val]      val----0/1\n");
	printf("gpio notify [gpio] [pid]     notify pid and proc signal\n");
	printf("gpio led    [gpio] [on] [off] [blink] [reset] [times]\n");

	exit(1);
}

void gpio_led_ctrl(ralink_gpio_led_info *led_data)
{
	int gpio_fd;

	gpio_fd = open(GPIO_DEV, O_RDONLY);
	if (gpio_fd < 0) {
		return 1;
	}
	
	ioctl(gpio_fd, RALINK_GPIO_LED_SET, led_data);
	
	close(gpio_fd);
	
	return 0;
}

int main(int argc, char *argv[])
{
	int data;
	int gpio;
	int gpio_reg;
	int offset;
	int pid;
	ralink_gpio_led_info led_info;
	
	if (argc < 3) {
		printf("param too low");
	}

	gpio_init_dev();

	if (argc < 2) {
		usage();
	}
	if ( !strcmp("getdir", argv[1]) && (3 == argc) ) {
		gpio = atoi(argv[2]);
		if(gpio >= 0 && gpio <= 31) {
			gpio_reg = gpio3100;
			offset = 1<<gpio;
		} else if (gpio >= 32 && gpio <= 63) {
			gpio_reg = gpio6332;
			offset = 1<<(gpio-32);
		} else {
			gpio_reg= gpio9564;
			offset = 1<<(gpio-64);
		}
		
		data = gpio_get_dir(gpio_reg);
		
		printf("gpio:%d dir:%d\n", gpio, (data&offset)>>gpio);
	} else if ( !strcmp("setdir", argv[1]) && (4 == argc) ) {
		gpio = atoi(argv[2]);
		if(gpio >=0 && gpio <= 31) {
			gpio_reg = gpio3100;
			offset = 1<<gpio;
		} else if (gpio >= 32 && gpio <= 63) {
			gpio_reg = gpio6332;
			offset = 1<<(gpio-32);
		} else {
			gpio_reg= gpio9564;
			offset = 1<<(gpio-64);
		}
		data = gpio_get_dir(gpio_reg);
		
		if (atoi(argv[3]) == 1) {
			data |= (1<<gpio);
		} else {
			data &= ~(1<<gpio);
		}

		gpio_set_dir(gpio_reg, data);
		
	} else if (!strcmp("read", argv[1]) && (3 == argc) ) {
		gpio = atoi(argv[2]);
		if(gpio >=0 && gpio <= 31) {
			gpio_reg = gpio3100;
			offset = 1<<gpio;
		} else if (gpio >= 32 && gpio <= 63) {
			gpio_reg = gpio6332;
			offset = 1<<(gpio-32);
		} else {
			gpio_reg= gpio9564;
			offset = 1<<(gpio-64);
		}

		data = gpio_read(gpio_reg);

		printf("gpio:%d val:%d\n", gpio, (data&(1<<gpio)) >> gpio);
	} else if (!strcmp("write", argv[1]) &&(4 == argc) ) {
		gpio = atoi(argv[2]);
		if(gpio >=0 && gpio <= 31) {
			gpio_reg = gpio3100;
			offset = 1<<gpio;
		} else if (gpio >= 32 && gpio <= 63) {
			gpio_reg = gpio6332;
			offset = 1<<(gpio-32);
		} else {
			gpio_reg= gpio9564;
			offset = 1<<(gpio-64);
		}

		data = gpio_read(gpio_reg);

		if (atoi(argv[3]) == 1) {
			data |= (1<<gpio);
		} else {
			data &= ~(1<<gpio);
		}
		printf("gpio set:%x \n", data);

		gpio_write(gpio_reg, data);
		
	} else if (!strcmp("notify", argv[1]) && (4 == argc)) {
		//注册通知处理函数
		gpio = atoi(argv[2]);
		pid = atoi(argv[3]);
		
		gpio_int_reg(gpio, pid);
		
	} else if (!strcmp("cancel", argv[1]) && (4 == argc)) {
		gpio = atoi(argv[2]);
		gpio_int_unreg(gpio);
	} 
	#if 1
	else if (!strcmp("led", argv[1]) && (argc == 8)) {
		led_info.gpio = atoi(argv[2]);
		led_info.on = atoi(argv[3]);
		led_info.off = atoi(argv[4]);
		led_info.blinks = atoi(argv[5]);
		led_info.rests = atoi(argv[6]);
		led_info.times = atoi(argv[7]);
		printf("gpio:%d on:%d off:%d blinks:%d rests:%d times:%d\n",
			led_info.gpio, led_info.on, led_info.off, led_info.blinks,
			led_info.rests, led_info.times);
		gpio_led_ctrl(&led_info);
	} 
	#endif
	else {
		usage();
		exit(1);
	}

	return 0;
}

